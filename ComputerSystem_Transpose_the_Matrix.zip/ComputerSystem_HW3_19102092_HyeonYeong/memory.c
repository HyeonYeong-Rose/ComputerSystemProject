#include<stdio.h>
#include <malloc.h>

struct rec
{
	int i;
	float PI;
	char A;

};

int main() { 
	struct rec *ptr_one;
	struct rec one;
	ptr_one = &one;
	ptr_one = malloc(sizeof(one));

	printf("Memory is allocated at %p (size : %d)\n", ptr_one, sizeof(one));

	one.i = 10;
	one.PI = 3.14;
	one.A = 'a';

	printf("First value: %d\n", one.i);
	printf("Second value: %f\n", one.PI);
	printf("Third value: %c\n", one.A);

	free(ptr_one);
	
	printf("Memory is deallocated at %p\n", ptr_one);

	return 0;
}