#include<stdio.h>
#include <malloc.h>
#include<stdlib.h>
#include<string.h>
#define _CRT_SECURE_NO_WARNINGS
#define MAX_LENGTH 10

int main() {

	char *str1;
	char str2[100];

	str1 = malloc(sizeof("19102092"));
	strcpy_s(str1, MAX_LENGTH,"19102092");
	printf("str1: %s, %p\n", str1, str1);

	strcpy_s(str2, MAX_LENGTH,"19102092");
	printf("str2: %s, %p\n", str2, str2);

	free(str1);

	return 0;
}