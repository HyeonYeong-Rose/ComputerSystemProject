#include <stdio.h>

int printmatrix(int matrix[4][4]) {
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			printf("  %2d", matrix[i][j]);
		}
		printf("\n");
	}
	return 0;
}

int main(void) {
	
	int matrix[4][4];

	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			printf("Input numbers to make a matrix[%d][%d]: ", i, j);
			scanf("%d", &matrix[i][j]);

		}
	}
	printf("Before transposed\n");
	printmatrix(matrix);

	int transpose[4][4];
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			transpose[j][i] = matrix[i][j];
		}
	}
	printf("After transposed\n");
	printmatrix(transpose);

	int addition[4][4];
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			addition[i][j] = matrix[i][j] + transpose[i][j];
		}
	}
	printf("addition result\n");
	printmatrix(addition);

	return 0;
}
